import{w as e,o as t,x as a}from"./chunk-EPOLDU6W-CKX40gY-.js";const n=e(function(){return t.jsx(a,{to:"/manager/overview",replace:!0})});export{n as default};
