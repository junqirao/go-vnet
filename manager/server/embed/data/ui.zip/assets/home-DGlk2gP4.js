import{w as e,o,x as t}from"./chunk-EPOLDU6W-CKX40gY-.js";const s=e(function(){return o.jsx(t,{to:"/manager/overview",replace:!0})});export{s as default};
